/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ana.teixeira
 */
public class Usuario {
    private int id;
    private String name;
    private int user_type;
    private String city;
    private String federative_unit;
    private String recep_validated;
    private String passsword;

    public Usuario(int id, String name, int user_type, String city, String federative_unit, String recep_validated, String passswoard) {
        this.id = id;
        this.name = name;
        this.user_type = user_type;
        this.city = city;
        this.federative_unit = federative_unit;
        this.recep_validated = recep_validated;
        this.passsword = passsword;
    }

    public Usuario(String name, String passsword) {
        this.name = name;
        this.passsword = passsword;
    }

    public Usuario(String usuario, String cidade, String uf, String senha) {//ESSE É O METODO CONSTRUTOR PARA O TESTE NAO É NECESSARIO
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUser_type() {
        return user_type;
    }

    public void setUser_type(int user_type) {
        this.user_type = user_type;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getFederative_unit() {
        return federative_unit;
    }

    public void setFederative_unit(String federative_unit) {
        this.federative_unit = federative_unit;
    }

    public String getRecep_validated() {
        return recep_validated;
    }

    public void setRecep_validated(String recep_validated) {
        this.recep_validated = recep_validated;
    }

    public String getPasssword() {
        return passsword;
    }

    public void setPasssword(String passsword) {
        this.passsword = passsword;
    }
    
}
