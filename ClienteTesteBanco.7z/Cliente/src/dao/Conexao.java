/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ana.teixeira
 */
public class Conexao {
        
    //2 TENTATIVA DE ABRIR O BANCO
    /*public static void main (String[] args){
        
        try {
            Class.forName("com.mysql.jbdc.Driver");
        } catch (ClassNotFoundException ex){
            System.out.println("Driver do banco de dados não localizado");
        }
        
    }]*/
    
    //CONEXAO ESTABELECIDA TESTE OK!
    public Connection getConnection() throws SQLException { 
        Connection conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/distribuidos","postgres","pururuca");
        return conexao;
    }




}
