/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Usuario;
import view.FormCadastroView;

/**
 *
 * @author ana.teixeira
 */
public class UsuarioDAO {
    
    private final Connection connection;

    public UsuarioDAO(Connection connection) {
        this.connection = connection;
    }
    
    //função que passa o user e ela trata a inserção no bd
    public void insert(Usuario usuario) throws SQLException{
            
            String sql = "insert into usuario (id, name,user_type, city, federative_unit, recep_validated, password) values ('"+usuario.getId() +"','"+usuario.getName()+"','"+usuario.getUser_type()+"','"+usuario.getCity()+"','"+usuario.getFederative_unit()+"','"+usuario.getRecep_validated()+"','"+usuario.getPasssword()+"')";         
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();        
            connection.close();
            
     
        }
    }
    

