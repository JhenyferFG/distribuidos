
package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class Server {
        
    //private void fechaSocket(Socket s) throws IOException {
      //  s.close();
    //}
    /*private void trataConexao (Socket socket) throws IOException
    {
        
    try {    
    //streams de entrada e saúda
        
    ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
    ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
    
    /*protocolo
    Cliente --> HELLO
        Server < --- HELLO WORD!
    
    //Tratamento de conversação entre cliente e servidor (tratar protocolo);
    String msg = input.readUTF();
        System.out.println("Mensagem recebida");
        output.writeUTF("HELLO WORD!");
    
    
    
    
    } catch (IOException e){
    //tratamento de falhas
    }finally{
    //final do tratamento do protocolo
    //fechar socket de comunicação entre servidor/cliente
            fechaSocket(socket);
    }      
    
    }

     */
    public static void main(String[] args) {
     try { 
		//criando o serviço de escuta do serviçp			
		 ServerSocket servidor = new ServerSocket(3334);
		 System.out.println("Servidor iniciado na porta 3334");
		 
		 //criando o canal de comunicação do serviço
		 Socket cliente = servidor.accept();
		 System.out.println("Cliente do ip: "+ cliente.getInetAddress().getHostAddress());
		 
		 
                 Scanner entrada = new Scanner(cliente.getInputStream());
		 while(entrada.hasNextLine())
		 {
		 System.out.println(entrada.nextLine());	 
		 }
		 
		 entrada.close();
		 servidor.close();
	 
		} catch (IOException ex) {
			System.out.println("Erro ao criar o servidor");
		}
    }
    
}
